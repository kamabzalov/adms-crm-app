export interface ActionStatus {
    status: string;
}
