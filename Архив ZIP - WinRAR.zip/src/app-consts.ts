export const API_URL = 'https://app.admss.com/api/v1/';
