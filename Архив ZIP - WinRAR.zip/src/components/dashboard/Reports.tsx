export const Reports = () => {
    return (
        <>
            <div className='col-12'>
                <div className='card card-custom mb-5'>
                    <div className='card-header'>
                        <h3 className='card-title fw-bolder text-dark'>Reports</h3>
                    </div>
                    <div className='card-body'>We're still working on this page</div>
                </div>
            </div>
        </>
    );
};
